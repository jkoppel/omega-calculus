# Changelog for omega-calculus

## Unreleased changes
