# omega-calculus

Requirements: https://www.haskellstack.org/

To run:
  * stack build
  * stack exec omega-calculus-exe


Has an example from the paper hardcoded.